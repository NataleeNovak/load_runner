Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("success.txt", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	
	web_reg_save_param_regexp(
		"ParamName=userSession",
		"RegExp=name=\"userSession\"\\ value=\"(.*?)\"/>\\\n<table\\ border",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);
		
	web_reg_save_param("userSession",
		"LB/IC=name=\"userSession\" value=\"",
		"RB=\"/>",
		LAST);

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("itinerary_cancel");

	/* LOGIN */

	lr_start_transaction("1_transaction_login");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(5);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=body", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value={userSession}", ENDITEM, 
		"Name=username", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=login.x", "Value=50", ENDITEM, 
		"Name=login.y", "Value=4", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	lr_end_transaction("1_transaction_login",LR_AUTO);
	
	/* CLICK ITINERARY */

	lr_start_transaction("2_transaction_itinerary");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(5);
	
	web_reg_save_param("flightIds",
	"LB/IC=name=\"flightID\" value=\"",
	"RB=\"  />",
	"Ord=ALL",
	LAST);

	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("2_transaction_itinerary",LR_AUTO);
	
	/* CANCELLING FLIGHT */

	lr_start_transaction("3_transaction_cancel_flight");

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(5);

	web_submit_data("itinerary.pl", 
		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM, 
		"Name=flightID", "Value=210300759-93377-JB", ENDITEM, 
		"Name=flightID", "Value=210300759-1615-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-254112-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-331035-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-407958-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-484881-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-561804-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-638727-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-715650-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-792573-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-869496-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-946419-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-1023342-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-1100265-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-1177189-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-1254112-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-1331035-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-1407958-JB", ENDITEM, 
		"Name=flightID", "Value=210297416-1484881-JB", ENDITEM, 
		"Name=flightID", "Value=210297424-1561835-JB", ENDITEM, 
		"Name=flightID", "Value=210297424-1638758-JB", ENDITEM, 
		"Name=flightID", "Value=210297424-1715681-JB", ENDITEM, 
		"Name=flightID", "Value=210297424-1792604-JB", ENDITEM, 
		"Name=removeFlights.x", "Value=24", ENDITEM, 
		"Name=removeFlights.y", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=21", ENDITEM, 
		"Name=.cgifields", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=17", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		"Name=.cgifields", "Value=22", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=18", ENDITEM, 
		"Name=.cgifields", "Value=23", ENDITEM, 
		"Name=.cgifields", "Value=16", ENDITEM, 
		"Name=.cgifields", "Value=13", ENDITEM, 
		"Name=.cgifields", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=3", ENDITEM, 
		"Name=.cgifields", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=20", ENDITEM, 
		"Name=.cgifields", "Value=14", ENDITEM, 
		"Name=.cgifields", "Value=15", ENDITEM, 
		"Name=.cgifields", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=19", ENDITEM, 
		"Name=.cgifields", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("3_transaction_cancel_flight",LR_AUTO);

	lr_think_time(5);
	
	/* SIGNING OFF */

	lr_start_transaction("4_transaction_sign_off");

	web_url("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("4_transaction_sign_off",LR_AUTO);

	lr_end_transaction("itinerary_cancel",LR_AUTO);

	return 0;
}